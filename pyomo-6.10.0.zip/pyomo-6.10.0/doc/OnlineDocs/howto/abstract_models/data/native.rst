Using Standard Data Types
=========================

Defining Constant Values
------------------------

In many cases, Pyomo models can be constructed without :class:`Set` and
:class:`~Param` data components.  Native Python data types
class can be simply used to define constant values in Pyomo expressions.
Consequently, Python sets, lists and dictionaries can be used to
construct Pyomo models, as well as a wide range of other Python classes.

.. admonition:: TODO 

    More examples here:  set, list, dict, numpy, pandas.


Initializing Set and Parameter Components
-----------------------------------------

The :class:`~pyomo.environ.Set` and :class:`~pyomo.environ.Param` components used in a Pyomo model
can also be initialized with standard Python data types.  This
enables some modeling efficiencies when manipulating sets (e.g.
when re-using sets for indices), and it supports validation of set
and parameter data values.  The :class:`~pyomo.environ.Set`
and :class:`~pyomo.environ.Param` components are
initialized with Python data using the ``initialize`` option.

Set Components
^^^^^^^^^^^^^^

In general, :class:`~pyomo.environ.Set` components
can be initialized with iterable data.  For example, simple sets
can be initialized with:

* list, set and tuple data:

    .. literalinclude:: /src/dataportal/set_initialization_decl2.spy
        :language: python

* generators:

    .. literalinclude:: /src/dataportal/set_initialization_decl3.spy
        :language: python

* numpy arrays:

    .. literalinclude:: /src/dataportal/set_initialization_decl4.spy
        :language: python

Sets can also be indirectly initialized with functions that return
native Python data:

.. literalinclude:: /src/dataportal/set_initialization_decl5.spy
    :language: python

Indexed sets can be initialized with dictionary data where the
dictionary values are iterable data:

.. literalinclude:: /src/dataportal/set_initialization_decl6.spy
    :language: python


Parameter Components
^^^^^^^^^^^^^^^^^^^^

When a parameter is a single value, then a :class:`~pyomo.environ.Param`
component can be simply initialized with a value:

.. literalinclude:: /src/dataportal/param_initialization_decl1.spy
    :language: python

More generally, :class:`~pyomo.environ.Param`
components can be initialized with dictionary data where the dictionary
values are single values:

.. literalinclude:: /src/dataportal/param_initialization_decl2.spy
    :language: python

Parameters can also be indirectly initialized with functions that
return native Python data:

.. literalinclude:: /src/dataportal/param_initialization_decl3.spy
    :language: python

