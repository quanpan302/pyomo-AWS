Debugging Models
================

TODO
