Pyomo Component Design
======================

TODO
